

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface PreferenceTag {
  id: string;
  label: string;
  icon: string;
  category: 'travel-type' | 'transport' | 'accommodation';
}

const PlanInputPage: React.FC = () => {
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [travelRequirements, setTravelRequirements] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [showVoiceStatus, setShowVoiceStatus] = useState(false);
  const [selectedPreferences, setSelectedPreferences] = useState<Set<string>>(new Set());
  const [isGenerating, setIsGenerating] = useState(false);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '智能行程规划 - 途智行';
    return () => { document.title = originalTitle; };
  }, []);

  // 响应式处理
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleSidebarToggle = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleVoiceInput = () => {
    console.log('需要调用第三方接口实现语音识别功能');
    
    if (!isRecording) {
      setIsRecording(true);
      setShowVoiceStatus(true);
      
      // 模拟语音识别过程
      setTimeout(() => {
        const sampleText = '我想去日本东京，5天，预算1万元，喜欢美食和动漫，带一个5岁孩子。';
        setTravelRequirements(sampleText);
        
        setIsRecording(false);
        setShowVoiceStatus(false);
      }, 3000);
    } else {
      setIsRecording(false);
      setShowVoiceStatus(false);
    }
  };

  const handleExamplePrompt = (text: string) => {
    setTravelRequirements(text);
  };

  const handlePreferenceToggle = (preferenceId: string) => {
    const newSelectedPreferences = new Set(selectedPreferences);
    if (newSelectedPreferences.has(preferenceId)) {
      newSelectedPreferences.delete(preferenceId);
    } else {
      newSelectedPreferences.add(preferenceId);
    }
    setSelectedPreferences(newSelectedPreferences);
  };

  const handleGenerateTrip = () => {
    const requirements = travelRequirements.trim();
    
    if (!requirements) {
      alert('请输入旅行需求');
      return;
    }
    
    setIsGenerating(true);
    
    // 模拟AI生成过程
    setTimeout(() => {
      const tripId = 'trip_' + Date.now();
      navigate(`/plan-detail?tripId=${tripId}`);
    }, 2000);
  };

  const handleClearInput = () => {
    setTravelRequirements('');
    setSelectedPreferences(new Set());
  };

  const preferenceTags: PreferenceTag[] = [
    { id: 'food', label: '美食', icon: 'fas fa-utensils', category: 'travel-type' },
    { id: 'shopping', label: '购物', icon: 'fas fa-shopping-bag', category: 'travel-type' },
    { id: 'history', label: '历史', icon: 'fas fa-landmark', category: 'travel-type' },
    { id: 'nature', label: '自然', icon: 'fas fa-mountain', category: 'travel-type' },
    { id: 'family', label: '亲子', icon: 'fas fa-child', category: 'travel-type' },
    { id: 'solo', label: '独自旅行', icon: 'fas fa-user', category: 'travel-type' },
    { id: 'photography', label: '摄影', icon: 'fas fa-camera', category: 'travel-type' },
    { id: 'culture', label: '文化', icon: 'fas fa-theater-masks', category: 'travel-type' },
    
    { id: 'high-speed-rail', label: '高铁', icon: 'fas fa-train', category: 'transport' },
    { id: 'plane', label: '飞机', icon: 'fas fa-plane', category: 'transport' },
    { id: 'self-drive', label: '自驾', icon: 'fas fa-car', category: 'transport' },
    { id: 'bus', label: '公交', icon: 'fas fa-bus', category: 'transport' },
    
    { id: 'economic', label: '经济型', icon: 'fas fa-bed', category: 'accommodation' },
    { id: 'comfortable', label: '舒适型', icon: 'fas fa-star', category: 'accommodation' },
    { id: 'luxury', label: '豪华型', icon: 'fas fa-star', category: 'accommodation' },
    { id: 'homestay', label: '特色民宿', icon: 'fas fa-home', category: 'accommodation' }
  ];

  const examplePrompts = [
    '北京3日游，预算3000元',
    '上海迪士尼2日游，带孩子',
    '成都美食之旅，喜欢火锅',
    '三亚度假，预算5000元'
  ];

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
              <i className="fas fa-route text-white text-lg"></i>
            </div>
            <h1 className="text-xl font-bold text-text-primary">途智行</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/my-trips" className="text-text-secondary hover:text-primary py-1 transition-colors">我的行程</Link>
            <Link to="/user-profile" className="text-text-secondary hover:text-primary py-1 transition-colors">个人中心</Link>
          </nav>
          
          {/* 搜索框和用户操作区 */}
          <div className="flex items-center space-x-4">
            <div className="hidden lg:block">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="搜索目的地..." 
                  className="w-64 pl-10 pr-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <img 
                src="https://s.coze.cn/image/C3liRHsd8_M/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full"
              />
              <span className="text-sm text-text-primary">小雨</span>
            </div>
            <button 
              onClick={handleSidebarToggle}
              className="md:hidden p-2 text-text-secondary hover:text-primary"
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>
        </div>
      </header>

      {/* 左侧菜单 */}
      <aside className={`fixed left-0 top-16 bottom-0 w-60 bg-white shadow-sm z-40 ${styles.sidebarTransition} ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        <div className="p-4">
          <nav className="space-y-2">
            <Link to="/home" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-home text-lg"></i>
              <span>首页</span>
            </Link>
            <Link to="/plan-input" className="flex items-center space-x-3 px-4 py-3 text-primary bg-blue-50 rounded-lg">
              <i className="fas fa-route text-lg"></i>
              <span className="font-medium">行程规划</span>
            </Link>
            <Link to="/my-trips" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-list text-lg"></i>
              <span>我的行程</span>
            </Link>
            <Link to="/budget-manage" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-wallet text-lg"></i>
              <span>预算管理</span>
            </Link>
            <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-user text-lg"></i>
              <span>个人中心</span>
            </Link>
          </nav>
        </div>
      </aside>

      {/* 主内容区 */}
      <main className="ml-60 mt-16 min-h-screen transition-all duration-300 md:ml-60">
        {/* 页面头部 */}
        <div className="bg-white border-b border-border-light px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-text-primary">智能行程规划</h1>
              <nav className="flex items-center space-x-2 text-sm text-text-secondary mt-1">
                <Link to="/home" className="hover:text-primary">首页</Link>
                <i className="fas fa-chevron-right text-xs"></i>
                <span className="text-primary">行程规划</span>
              </nav>
            </div>
          </div>
        </div>

        {/* 主要内容区域 */}
        <div className="p-8">
          <div className="max-w-4xl mx-auto">
            {/* 需求输入区 */}
            <div className="bg-white rounded-xl shadow-card p-8 mb-8">
              <h2 className="text-xl font-semibold text-text-primary mb-6">告诉我们你的旅行想法</h2>
              
              {/* 文本输入框 */}
              <div className="mb-6">
                <label htmlFor="travel-requirements" className="block text-sm font-medium text-text-primary mb-3">
                  请详细描述你的旅行需求（目的地、日期、预算、人数、偏好等）
                </label>
                <div className="relative">
                  <textarea 
                    id="travel-requirements" 
                    name="travel-requirements"
                    rows={4} 
                    placeholder="例如：我想去日本东京，5天，预算1万元，喜欢美食和动漫，带一个5岁孩子。"
                    value={travelRequirements}
                    onChange={(e) => setTravelRequirements(e.target.value)}
                    className="w-full px-4 py-3 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                  />
                  <button 
                    onClick={handleVoiceInput}
                    className="absolute bottom-3 right-3 p-2 text-text-secondary hover:text-primary transition-colors"
                    title="语音输入"
                  >
                    <i className={`text-lg ${isRecording ? 'fas fa-stop text-danger' : 'fas fa-microphone'}`}></i>
                  </button>
                </div>
                
                {/* 语音识别状态 */}
                {showVoiceStatus && (
                  <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className={styles.loadingSpinner}></div>
                      <span className="text-sm text-primary">正在聆听...</span>
                    </div>
                  </div>
                )}
              </div>

              {/* 示例提示 */}
              <div className="mb-6">
                <p className="text-sm text-text-secondary mb-3">常见输入示例：</p>
                <div className="flex flex-wrap gap-2">
                  {examplePrompts.map((prompt, index) => (
                    <button 
                      key={index}
                      onClick={() => handleExamplePrompt(prompt)}
                      className="px-3 py-1 text-sm bg-gray-100 text-text-secondary rounded-full hover:bg-gray-200 transition-colors"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>

              {/* 偏好选择区 */}
              <div className="mb-6">
                <h3 className="text-lg font-medium text-text-primary mb-4">选择你的旅行偏好</h3>
                
                {/* 旅行类型 */}
                <div className="mb-4">
                  <p className="text-sm text-text-secondary mb-3">旅行类型</p>
                  <div className="flex flex-wrap gap-2">
                    {preferenceTags
                      .filter(tag => tag.category === 'travel-type')
                      .map(tag => (
                        <button 
                          key={tag.id}
                          onClick={() => handlePreferenceToggle(tag.id)}
                          className={`${styles.preferenceTag} px-4 py-2 text-sm border border-border-light rounded-full hover:border-primary ${selectedPreferences.has(tag.id) ? styles.selected : ''}`}
                        >
                          <i className={`${tag.icon} mr-1`}></i>{tag.label}
                        </button>
                      ))}
                  </div>
                </div>

                {/* 交通偏好 */}
                <div className="mb-4">
                  <p className="text-sm text-text-secondary mb-3">交通偏好</p>
                  <div className="flex flex-wrap gap-2">
                    {preferenceTags
                      .filter(tag => tag.category === 'transport')
                      .map(tag => (
                        <button 
                          key={tag.id}
                          onClick={() => handlePreferenceToggle(tag.id)}
                          className={`${styles.preferenceTag} px-4 py-2 text-sm border border-border-light rounded-full hover:border-primary ${selectedPreferences.has(tag.id) ? styles.selected : ''}`}
                        >
                          <i className={`${tag.icon} mr-1`}></i>{tag.label}
                        </button>
                      ))}
                  </div>
                </div>

                {/* 住宿偏好 */}
                <div>
                  <p className="text-sm text-text-secondary mb-3">住宿偏好</p>
                  <div className="flex flex-wrap gap-2">
                    {preferenceTags
                      .filter(tag => tag.category === 'accommodation')
                      .map(tag => (
                        <button 
                          key={tag.id}
                          onClick={() => handlePreferenceToggle(tag.id)}
                          className={`${styles.preferenceTag} px-4 py-2 text-sm border border-border-light rounded-full hover:border-primary ${selectedPreferences.has(tag.id) ? styles.selected : ''}`}
                        >
                          <i className={`${tag.icon} mr-1`}></i>{tag.label === '豪华型' ? '豪华型' : tag.label}
                          {tag.label === '豪华型' && <i className="fas fa-star mr-1"></i>}
                        </button>
                      ))}
                  </div>
                </div>
              </div>

              {/* 操作按钮区 */}
              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={handleGenerateTrip}
                  disabled={isGenerating}
                  className="flex-1 px-8 py-4 bg-gradient-to-r from-primary to-secondary text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300 flex items-center justify-center"
                >
                  {isGenerating ? (
                    <>
                      <div className={`${styles.loadingSpinner} w-4 h-4 mr-2`}></div>
                      生成中...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-magic mr-2"></i>
                      生成智能行程
                    </>
                  )}
                </button>
                <button 
                  onClick={handleClearInput}
                  className="px-6 py-4 border-2 border-border-light text-text-secondary rounded-lg font-medium hover:border-primary hover:text-primary transition-colors"
                >
                  <i className="fas fa-eraser mr-2"></i>
                  清空输入
                </button>
              </div>
            </div>

            {/* 功能介绍区 */}
            <div className="grid md:grid-cols-3 gap-6">
              {/* AI智能分析 */}
              <div className={`bg-white rounded-xl p-6 shadow-card ${styles.cardHover}`}>
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-brain text-white text-xl"></i>
                </div>
                <h3 className="text-lg font-semibold text-text-primary mb-3">AI智能分析</h3>
                <p className="text-sm text-text-secondary">
                  深度理解你的旅行需求，结合大数据分析，为你推荐最适合的行程方案。
                </p>
              </div>

              {/* 个性化推荐 */}
              <div className={`bg-white rounded-xl p-6 shadow-card ${styles.cardHover}`}>
                <div className="w-12 h-12 bg-gradient-to-br from-tertiary to-primary rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-user-cog text-white text-xl"></i>
                </div>
                <h3 className="text-lg font-semibold text-text-primary mb-3">个性化推荐</h3>
                <p className="text-sm text-text-secondary">
                  根据你的兴趣爱好、预算和时间，量身定制专属于你的旅行体验。
                </p>
              </div>

              {/* 实时优化 */}
              <div className={`bg-white rounded-xl p-6 shadow-card ${styles.cardHover}`}>
                <div className="w-12 h-12 bg-gradient-to-br from-secondary to-tertiary rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-sync-alt text-white text-xl"></i>
                </div>
                <h3 className="text-lg font-semibold text-text-primary mb-3">实时优化</h3>
                <p className="text-sm text-text-secondary">
                  动态调整行程安排，确保最佳体验，随时应对突发情况。
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PlanInputPage;

