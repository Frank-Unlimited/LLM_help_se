

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';
import { TripData } from './types';

const MyTripsPage: React.FC = () => {
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [currentDeleteTripId, setCurrentDeleteTripId] = useState<string | null>(null);
  const [currentShareTripId, setCurrentShareTripId] = useState<string | null>(null);
  const [tripSearchTerm, setTripSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [destinationFilter, setDestinationFilter] = useState('');

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '我的行程 - 途智行';
    return () => { document.title = originalTitle; };
  }, []);

  // 响应式处理
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsSidebarOpen(false);
      }
    };
    
    window.addEventListener('resize', handleResize);
    handleResize();
    
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // 模拟行程数据
  const tripsData: TripData[] = [
    {
      id: 'trip-001',
      title: '东京动漫美食之旅',
      destination: '日本东京',
      dates: '2024年3月15日 - 3月20日',
      budget: 8500,
      spent: 3200,
      status: 'active',
      image: 'https://s.coze.cn/image/Wfu3diMcxMM/',
      imageAlt: '日本东京风景',
      imageCategory: '建筑城市'
    },
    {
      id: 'trip-002',
      title: '大理古城文化游',
      destination: '中国云南大理',
      dates: '2024年2月10日 - 2月16日',
      budget: 4200,
      spent: 3850,
      status: 'completed',
      image: 'https://s.coze.cn/image/23_UyiymSd8/',
      imageAlt: '云南大理风景',
      imageCategory: '自然风景'
    },
    {
      id: 'trip-003',
      title: '巴黎浪漫之旅',
      destination: '法国巴黎',
      dates: '2024年4月20日 - 4月27日',
      budget: 15000,
      status: 'draft',
      image: 'https://s.coze.cn/image/z6JqJRChMCo/',
      imageAlt: '法国巴黎风景',
      imageCategory: '建筑城市'
    },
    {
      id: 'trip-004',
      title: '普吉岛海岛度假',
      destination: '泰国普吉岛',
      dates: '2024年5月1日 - 5月7日',
      budget: 6800,
      status: 'draft',
      image: 'https://s.coze.cn/image/sgssUzFvSpY/',
      imageAlt: '泰国普吉岛风景',
      imageCategory: '自然风景'
    },
    {
      id: 'trip-005',
      title: '北京文化探索',
      destination: '中国北京',
      dates: '2024年1月20日 - 1月25日',
      budget: 3500,
      spent: 3680,
      status: 'completed',
      image: 'https://s.coze.cn/image/uR073fUC6XY/',
      imageAlt: '北京城市风景',
      imageCategory: '建筑城市'
    }
  ];

  // 筛选行程
  const filteredTrips = tripsData.filter(trip => {
    // 搜索筛选
    if (tripSearchTerm) {
      const searchTerm = tripSearchTerm.toLowerCase();
      if (!trip.title.toLowerCase().includes(searchTerm) && 
          !trip.destination.toLowerCase().includes(searchTerm)) {
        return false;
      }
    }

    // 状态筛选
    if (statusFilter && trip.status !== statusFilter) {
      return false;
    }

    // 目的地筛选
    if (destinationFilter) {
      const isInternational = ['日本', '法国', '泰国'].some(country => 
        trip.destination.includes(country)
      );
      
      if (destinationFilter === 'international' && !isInternational) {
        return false;
      } else if (destinationFilter === 'domestic' && isInternational) {
        return false;
      }
    }

    return true;
  });

  // 处理侧边栏切换
  const handleSidebarToggle = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // 处理新建行程
  const handleNewTrip = () => {
    navigate('/plan-input');
  };

  // 处理查看行程
  const handleViewTrip = (tripId: string) => {
    navigate(`/plan-detail?tripId=${tripId}`);
  };

  // 处理编辑行程
  const handleEditTrip = (e: React.MouseEvent, tripId: string) => {
    e.stopPropagation();
    navigate(`/plan-detail?tripId=${tripId}&mode=edit`);
  };

  // 处理分享行程
  const handleShareTrip = (e: React.MouseEvent, tripId: string) => {
    e.stopPropagation();
    setCurrentShareTripId(tripId);
    setShowShareModal(true);
  };

  // 处理删除行程
  const handleDeleteTrip = (e: React.MouseEvent, tripId: string) => {
    e.stopPropagation();
    setCurrentDeleteTripId(tripId);
    setShowDeleteModal(true);
  };

  // 确认删除
  const handleConfirmDelete = () => {
    if (currentDeleteTripId) {
      console.log('删除行程:', currentDeleteTripId);
      // 这里应该调用删除API
      setShowDeleteModal(false);
      setCurrentDeleteTripId(null);
    }
  };

  // 取消删除
  const handleCancelDelete = () => {
    setShowDeleteModal(false);
    setCurrentDeleteTripId(null);
  };

  // 复制分享链接
  const handleCopyLink = () => {
    const shareLink = `https://tuzhixing.com/share/${currentShareTripId}`;
    navigator.clipboard?.writeText(shareLink).then(() => {
      console.log('链接已复制');
    }).catch(() => {
      // 降级方案
      const textArea = document.createElement('textarea');
      textArea.value = shareLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      console.log('链接已复制');
    });
  };

  // 导出PDF
  const handleExportPdf = () => {
    console.log('需要调用第三方接口实现PDF导出功能');
  };

  // 关闭分享模态框
  const handleCloseShareModal = () => {
    setShowShareModal(false);
    setCurrentShareTripId(null);
  };

  // 获取状态徽章样式
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'draft':
        return `${styles.statusBadge} ${styles.statusDraft}`;
      case 'active':
        return `${styles.statusBadge} ${styles.statusActive}`;
      case 'completed':
        return `${styles.statusBadge} ${styles.statusCompleted}`;
      default:
        return styles.statusBadge;
    }
  };

  // 获取状态文本
  const getStatusText = (status: string) => {
    switch (status) {
      case 'draft':
        return '草稿';
      case 'active':
        return '进行中';
      case 'completed':
        return '已完成';
      default:
        return status;
    }
  };

  // 渲染预算信息
  const renderBudgetInfo = (trip: TripData) => {
    if (trip.status === 'active' && trip.spent) {
      const remaining = trip.budget - trip.spent;
      return (
        <div className="text-sm text-text-secondary">
          <span className="text-success">已花费 ¥{trip.spent.toLocaleString()}</span>
          <span className="text-text-secondary ml-2">剩余 ¥{remaining.toLocaleString()}</span>
        </div>
      );
    } else if (trip.status === 'completed' && trip.spent) {
      const difference = trip.spent - trip.budget;
      const isOver = difference > 0;
      return (
        <div className="text-sm text-text-secondary">
          <span className="text-success">实际花费 ¥{trip.spent.toLocaleString()}</span>
          <span className={`ml-2 ${isOver ? 'text-danger' : 'text-success'}`}>
            {isOver ? `超支 ¥${difference.toLocaleString()}` : `节省 ¥${Math.abs(difference).toLocaleString()}`}
          </span>
        </div>
      );
    } else {
      return (
        <div className="text-sm text-text-secondary">
          <span className="text-warning">待开始</span>
        </div>
      );
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 ${styles.gradientBg} rounded-lg flex items-center justify-center`}>
              <i className="fas fa-route text-white text-lg"></i>
            </div>
            <h1 className="text-xl font-bold text-text-primary">途智行</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/my-trips" className="text-primary font-medium border-b-2 border-primary py-1">我的行程</Link>
            <Link to="/user-profile" className="text-text-secondary hover:text-primary py-1 transition-colors">个人中心</Link>
          </nav>
          
          {/* 搜索框和用户操作区 */}
          <div className="flex items-center space-x-4">
            <div className="hidden lg:block">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="搜索目的地..." 
                  className="w-64 pl-10 pr-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <img 
                src="https://s.coze.cn/image/8wNJ0pRFEhg/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full"
              />
              <span className="text-sm text-text-primary">小雨</span>
            </div>
            <button 
              onClick={handleSidebarToggle}
              className="md:hidden p-2 text-text-secondary hover:text-primary"
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>
        </div>
      </header>

      {/* 左侧菜单 */}
      <aside className={`fixed left-0 top-16 bottom-0 w-60 bg-white shadow-sm z-40 ${styles.sidebarTransition} ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        <div className="p-4">
          <nav className="space-y-2">
            <Link to="/home" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-home text-lg"></i>
              <span>首页</span>
            </Link>
            <Link to="/plan-input" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-route text-lg"></i>
              <span>行程规划</span>
            </Link>
            <Link to="/my-trips" className="flex items-center space-x-3 px-4 py-3 text-primary bg-blue-50 rounded-lg">
              <i className="fas fa-list text-lg"></i>
              <span className="font-medium">我的行程</span>
            </Link>
            <Link to="/budget-manage" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-wallet text-lg"></i>
              <span>预算管理</span>
            </Link>
            <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-user text-lg"></i>
              <span>个人中心</span>
            </Link>
          </nav>
        </div>
      </aside>

      {/* 主内容区 */}
      <main className="ml-0 md:ml-60 mt-16 min-h-screen transition-all duration-300">
        {/* 页面头部 */}
        <div className="bg-white border-b border-border-light px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-text-primary">我的行程</h1>
              <nav className="flex items-center space-x-2 text-sm text-text-secondary mt-1">
                <Link to="/home" className="hover:text-primary">首页</Link>
                <i className="fas fa-chevron-right text-xs"></i>
                <span>我的行程</span>
              </nav>
            </div>
            <button 
              onClick={handleNewTrip}
              className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center space-x-2"
            >
              <i className="fas fa-plus"></i>
              <span>新建行程</span>
            </button>
          </div>
        </div>

        {/* 搜索和筛选区 */}
        <div className="bg-white border-b border-border-light px-8 py-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            {/* 搜索框 */}
            <div className="flex items-center space-x-4">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="搜索行程名称或目的地..." 
                  value={tripSearchTerm}
                  onChange={(e) => setTripSearchTerm(e.target.value)}
                  className={`w-80 pl-10 pr-4 py-2 border border-border-light rounded-lg ${styles.searchInput}`}
                />
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
              </div>
            </div>
            
            {/* 筛选条件 */}
            <div className="flex items-center space-x-4">
              <select 
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className={`px-4 py-2 border border-border-light rounded-lg ${styles.filterSelect}`}
              >
                <option value="">全部状态</option>
                <option value="draft">草稿</option>
                <option value="active">进行中</option>
                <option value="completed">已完成</option>
              </select>
              
              <select 
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className={`px-4 py-2 border border-border-light rounded-lg ${styles.filterSelect}`}
              >
                <option value="">全部日期</option>
                <option value="recent">最近一个月</option>
                <option value="this-month">本月</option>
                <option value="next-month">下月</option>
              </select>
              
              <select 
                value={destinationFilter}
                onChange={(e) => setDestinationFilter(e.target.value)}
                className={`px-4 py-2 border border-border-light rounded-lg ${styles.filterSelect}`}
              >
                <option value="">全部目的地</option>
                <option value="domestic">国内</option>
                <option value="international">国外</option>
              </select>
            </div>
          </div>
        </div>

        {/* 行程列表区 */}
        <div className="p-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTrips.map((trip) => (
              <div 
                key={trip.id}
                onClick={() => handleViewTrip(trip.id)}
                className={`bg-white rounded-xl shadow-card ${styles.cardHover} cursor-pointer`}
              >
                <div className="relative">
                  <img 
                    src={trip.image} 
                    alt={trip.imageAlt} 
                    className="w-full h-48 object-cover rounded-t-xl"
                  />
                  <div className="absolute top-4 right-4">
                    <span className={getStatusBadgeClass(trip.status)}>
                      {getStatusText(trip.status)}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-text-primary mb-2">{trip.title}</h3>
                  <div className="flex items-center text-text-secondary text-sm mb-3">
                    <i className="fas fa-map-marker-alt mr-2"></i>
                    <span>{trip.destination}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-text-secondary mb-4">
                    <div className="flex items-center">
                      <i className="fas fa-calendar mr-2"></i>
                      <span>{trip.dates}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-semibold text-primary">¥{trip.budget.toLocaleString()}</div>
                      <div className="text-xs">预算</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    {renderBudgetInfo(trip)}
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleViewTrip(trip.id); }}
                        className="p-2 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <i className="fas fa-eye"></i>
                      </button>
                      <button 
                        onClick={(e) => handleEditTrip(e, trip.id)}
                        className="p-2 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <i className="fas fa-edit"></i>
                      </button>
                      <button 
                        onClick={(e) => handleShareTrip(e, trip.id)}
                        className="p-2 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <i className="fas fa-share"></i>
                      </button>
                      <button 
                        onClick={(e) => handleDeleteTrip(e, trip.id)}
                        className="p-2 text-text-secondary hover:text-danger hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {/* 新建行程卡片 */}
            <div 
              onClick={handleNewTrip}
              className="border-2 border-dashed border-border-light rounded-xl p-8 text-center hover:border-primary hover:bg-blue-50 transition-colors cursor-pointer"
            >
              <div className={`w-16 h-16 ${styles.gradientBg} rounded-xl flex items-center justify-center mx-auto mb-4`}>
                <i className="fas fa-plus text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-2">创建新行程</h3>
              <p className="text-text-secondary text-sm">开始规划你的下一次旅行</p>
            </div>
          </div>
        </div>

        {/* 分页区 */}
        <div className="bg-white border-t border-border-light px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="text-sm text-text-secondary">
              显示第 1-6 条，共 12 条记录
            </div>
            <div className="flex items-center space-x-2">
              <button 
                className="px-3 py-2 text-sm text-text-secondary border border-border-light rounded-lg hover:bg-gray-50 transition-colors" 
                disabled
              >
                <i className="fas fa-chevron-left"></i>
                上一页
              </button>
              <button className="px-3 py-2 text-sm bg-primary text-white rounded-lg">1</button>
              <button className="px-3 py-2 text-sm text-text-secondary border border-border-light rounded-lg hover:bg-gray-50 transition-colors">2</button>
              <button className="px-3 py-2 text-sm text-text-secondary border border-border-light rounded-lg hover:bg-gray-50 transition-colors">
                下一页
                <i className="fas fa-chevron-right"></i>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* 删除确认模态框 */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50">
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-xl p-6 max-w-md w-full">
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-exclamation-triangle text-danger text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-text-primary mb-2">确认删除</h3>
                <p className="text-text-secondary mb-6">确定要删除这个行程吗？删除后将无法恢复。</p>
                <div className="flex space-x-3">
                  <button 
                    onClick={handleCancelDelete}
                    className="flex-1 px-4 py-2 text-text-secondary border border-border-light rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    onClick={handleConfirmDelete}
                    className="flex-1 px-4 py-2 bg-danger text-white rounded-lg hover:bg-red-600 transition-colors"
                  >
                    删除
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 分享模态框 */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50">
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-xl p-6 max-w-md w-full">
              <div className="text-center">
                <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-share-alt text-primary text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-text-primary mb-2">分享行程</h3>
                <p className="text-text-secondary mb-6">复制链接分享给朋友，或导出为PDF格式</p>
                <div className="mb-4">
                  <input 
                    type="text" 
                    value={`https://tuzhixing.com/share/${currentShareTripId}`} 
                    readOnly 
                    className="w-full px-4 py-2 border border-border-light rounded-lg bg-gray-50 text-sm"
                  />
                </div>
                <div className="flex space-x-3">
                  <button 
                    onClick={handleCopyLink}
                    className="flex-1 px-4 py-2 text-primary border border-primary rounded-lg hover:bg-primary hover:text-white transition-colors"
                  >
                    <i className="fas fa-copy mr-2"></i>
                    复制链接
                  </button>
                  <button 
                    onClick={handleExportPdf}
                    className="flex-1 px-4 py-2 bg-secondary text-white rounded-lg hover:bg-purple-600 transition-colors"
                  >
                    <i className="fas fa-file-pdf mr-2"></i>
                    导出PDF
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 模态框背景点击关闭 */}
      {showDeleteModal && (
        <div 
          onClick={handleCancelDelete}
          className="fixed inset-0 z-40"
        />
      )}
      {showShareModal && (
        <div 
          onClick={handleCloseShareModal}
          className="fixed inset-0 z-40"
        />
      )}
    </div>
  );
};

export default MyTripsPage;

