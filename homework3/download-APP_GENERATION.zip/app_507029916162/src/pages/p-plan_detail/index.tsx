

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';
import { ActivityData, ExpenseData } from './types';

const PlanDetailPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // 状态管理
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [showActivityDrawer, setShowActivityDrawer] = useState(false);
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState<ActivityData | null>(null);
  const [expenseFormData, setExpenseFormData] = useState<ExpenseData>({
    amount: '',
    category: '',
    date: '',
    description: ''
  });

  // 活动数据
  const activityDataMap: Record<string, ActivityData> = {
    'activity-1': {
      title: '抵达东京成田机场',
      time: '09:00',
      location: '成田国际机场',
      description: '乘坐中国国际航空CA157航班从北京首都机场起飞，经过约3小时30分钟的飞行，于当地时间09:00抵达东京成田国际机场。',
      image: 'https://s.coze.cn/image/OAP3Yi8-dmM/',
      category: '交通',
      cost: '¥0'
    },
    'activity-2': {
      title: '前往酒店',
      time: '10:30',
      location: '成田机场 → 新宿',
      description: '在机场办理入境手续后，乘坐成田特快(N\'EX)前往东京市区，预计1小时到达新宿站，然后前往预订的酒店办理入住手续。',
      image: 'https://s.coze.cn/image/b3eUhhRr8oA/',
      category: '交通',
      cost: '¥3,000'
    },
    'activity-3': {
      title: '浅草寺观光',
      time: '14:00',
      location: '浅草寺',
      description: '参观东京最古老的寺庙，游览雷门、仲见世商店街，体验日本传统文化。可以品尝当地小吃，购买传统工艺品。',
      image: 'https://s.coze.cn/image/pDnDAaXfMPk/',
      category: '观光',
      cost: '免费'
    },
    'activity-4': {
      title: '一兰拉面晚餐',
      time: '19:00',
      location: '一兰拉面 浅草店',
      description: '品尝正宗的豚骨拉面，体验日本著名的拉面文化。一兰拉面以其浓郁的汤底和独特的个人小隔间而闻名。',
      image: 'https://s.coze.cn/image/tLHAFNZ-3ms/',
      category: '餐饮',
      cost: '¥1,200'
    },
    'activity-5': {
      title: '明治神宫参拜',
      time: '10:00',
      location: '明治神宫',
      description: '在东京市中心的绿洲中感受宁静与神圣，参观明治神宫的主殿，了解日本神道教文化。春季可以欣赏美丽的樱花。',
      image: 'https://s.coze.cn/image/L9xn8-GIEw4/',
      category: '观光',
      cost: '免费'
    },
    'activity-6': {
      title: '涩谷购物',
      time: '14:00',
      location: '涩谷区',
      description: '在东京最繁华的商业区尽情购物，参观涩谷十字路口，逛百货公司和特色小店，体验现代东京的活力。',
      image: 'https://s.coze.cn/image/eFh8-tbYnsc/',
      category: '购物',
      cost: '¥2,000'
    }
  };

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '行程详情 - 途智行';
    return () => { document.title = originalTitle; };
  }, []);

  // 响应式处理
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsSidebarOpen(false);
      }
    };
    
    window.addEventListener('resize', handleResize);
    handleResize();
    
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // 获取URL参数
  useEffect(() => {
    const tripId = searchParams.get('tripId');
    if (tripId) {
      console.log('加载行程ID:', tripId);
    }
  }, [searchParams]);

  // 事件处理函数
  const handleSidebarToggle = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleEditModeToggle = () => {
    setIsEditMode(true);
  };

  const handleSaveEdit = () => {
    setIsEditMode(false);
    alert('行程保存成功！');
  };

  const handleRecordExpense = () => {
    const today = new Date().toISOString().split('T')[0];
    setExpenseFormData(prev => ({ ...prev, date: today }));
    setShowExpenseModal(true);
  };

  const handleExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('记录开销:', expenseFormData);
    setShowExpenseModal(false);
    setExpenseFormData({ amount: '', category: '', date: '', description: '' });
    alert('开销记录保存成功！');
  };

  const handleExpenseInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setExpenseFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleShare = () => {
    setShowShareModal(true);
  };

  const handleCopyLink = () => {
    const shareLink = 'https://tuzhixing.com/share/trip/abc123';
    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareLink).then(() => {
        alert('链接已复制到剪贴板！');
      });
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = shareLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      alert('链接已复制到剪贴板！');
    }
  };

  const handleSocialShare = (platform: string) => {
    console.log(`分享到${platform}`);
    alert(`正在打开${platform}分享...`);
  };

  const handleDelete = () => {
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = () => {
    console.log('删除行程');
    alert('行程删除成功！');
    navigate('/my-trips');
  };

  const handleActivityClick = (activityId: string) => {
    const activity = activityDataMap[activityId];
    if (activity) {
      setSelectedActivity(activity);
      setShowActivityDrawer(true);
    }
  };

  const handleCloseDrawer = () => {
    setShowActivityDrawer(false);
    setSelectedActivity(null);
  };

  const handleCloseModal = (modalSetter: React.Dispatch<React.SetStateAction<boolean>>) => {
    modalSetter(false);
  };

  const handleModalOverlayClick = (e: React.MouseEvent, modalSetter: React.Dispatch<React.SetStateAction<boolean>>) => {
    if (e.target === e.currentTarget) {
      modalSetter(false);
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
              <i className="fas fa-route text-white text-lg"></i>
            </div>
            <h1 className="text-xl font-bold text-text-primary">途智行</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/my-trips" className="text-primary font-medium border-b-2 border-primary py-1">我的行程</Link>
            <Link to="/user-profile" className="text-text-secondary hover:text-primary py-1 transition-colors">个人中心</Link>
          </nav>
          
          {/* 搜索框和用户操作区 */}
          <div className="flex items-center space-x-4">
            <div className="hidden lg:block">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="搜索目的地..." 
                  className="w-64 pl-10 pr-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <img 
                src="https://s.coze.cn/image/6V44mo7ag_I/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full"
              />
              <span className="text-sm text-text-primary">小雨</span>
            </div>
            <button 
              onClick={handleSidebarToggle}
              className="md:hidden p-2 text-text-secondary hover:text-primary"
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>
        </div>
      </header>

      {/* 左侧菜单 */}
      <aside className={`fixed left-0 top-16 bottom-0 w-60 bg-white shadow-sm z-40 ${styles.sidebarTransition} ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        <div className="p-4">
          <nav className="space-y-2">
            <Link to="/home" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-home text-lg"></i>
              <span>首页</span>
            </Link>
            <Link to="/plan-input" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-route text-lg"></i>
              <span>行程规划</span>
            </Link>
            <Link to="/my-trips" className="flex items-center space-x-3 px-4 py-3 text-primary bg-blue-50 rounded-lg">
              <i className="fas fa-list text-lg"></i>
              <span className="font-medium">我的行程</span>
            </Link>
            <Link to="/budget-manage" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-wallet text-lg"></i>
              <span>预算管理</span>
            </Link>
            <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-user text-lg"></i>
              <span>个人中心</span>
            </Link>
          </nav>
        </div>
      </aside>

      {/* 主内容区 */}
      <main className={`ml-0 md:ml-60 mt-16 min-h-screen transition-all duration-300 ${isEditMode ? styles.editMode : ''}`}>
        {/* 页面头部 */}
        <div className="bg-white border-b border-border-light px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <nav className="text-sm text-text-secondary mb-2">
                <Link to="/my-trips" className="hover:text-primary">我的行程</Link>
                <span className="mx-2">/</span>
                <span className="text-text-primary">日本东京美食之旅</span>
              </nav>
              <h1 className={`text-2xl font-bold text-text-primary ${styles.editable}`}>日本东京美食之旅</h1>
            </div>
            <div className="flex items-center space-x-3">
              <button 
                onClick={handleEditModeToggle}
                className={`px-4 py-2 text-primary border border-primary rounded-lg hover:bg-primary hover:text-white transition-colors ${isEditMode ? 'hidden' : ''}`}
              >
                <i className="fas fa-edit mr-2"></i>编辑行程
              </button>
              <button 
                onClick={handleSaveEdit}
                className={`px-4 py-2 bg-success text-white rounded-lg hover:bg-green-600 transition-colors ${isEditMode ? '' : 'hidden'}`}
              >
                <i className="fas fa-save mr-2"></i>保存行程
              </button>
              <button 
                onClick={handleShare}
                className="px-4 py-2 text-secondary border border-secondary rounded-lg hover:bg-secondary hover:text-white transition-colors"
              >
                <i className="fas fa-share-alt mr-2"></i>分享
              </button>
              <button 
                onClick={handleDelete}
                className="px-4 py-2 text-danger border border-danger rounded-lg hover:bg-danger hover:text-white transition-colors"
              >
                <i className="fas fa-trash mr-2"></i>删除
              </button>
            </div>
          </div>
        </div>

        {/* 行程概览区 */}
        <section className="p-6">
          <div className="bg-white rounded-xl shadow-card p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-map-marker-alt text-white text-lg"></i>
                </div>
                <h3 className="text-sm font-medium text-text-secondary mb-1">目的地</h3>
                <p className={`text-lg font-semibold text-text-primary ${styles.editable}`}>日本东京</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-tertiary to-primary rounded-lg flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-calendar text-white text-lg"></i>
                </div>
                <h3 className="text-sm font-medium text-text-secondary mb-1">日期</h3>
                <p className={`text-lg font-semibold text-text-primary ${styles.editable}`}>2024.03.15 - 03.20</p>
                <p className="text-sm text-text-secondary">6天5夜</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-secondary to-tertiary rounded-lg flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-users text-white text-lg"></i>
                </div>
                <h3 className="text-sm font-medium text-text-secondary mb-1">人数</h3>
                <p className={`text-lg font-semibold text-text-primary ${styles.editable}`}>2人</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-warning to-danger rounded-lg flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-yen-sign text-white text-lg"></i>
                </div>
                <h3 className="text-sm font-medium text-text-secondary mb-1">预算</h3>
                <p className={`text-lg font-semibold text-text-primary ${styles.editable}`}>¥15,000</p>
                <p className="text-sm text-text-secondary">已花费 ¥8,500</p>
              </div>
            </div>
          </div>
        </section>

        {/* 费用管理模块 */}
        <section className="px-6 pb-6">
          <div className="bg-white rounded-xl shadow-card p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-text-primary">预算概览</h2>
              <button 
                onClick={handleRecordExpense}
                className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors"
              >
                <i className="fas fa-plus mr-2"></i>记录开销
              </button>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-primary">¥15,000</div>
                    <div className="text-sm text-text-secondary">总预算</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-warning">¥8,500</div>
                    <div className="text-sm text-text-secondary">已花费</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-success">¥6,500</div>
                    <div className="text-sm text-text-secondary">剩余</div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium text-text-secondary mb-3">费用分布</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">餐饮</span>
                    <span className="text-sm font-medium text-text-primary">¥3,200</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">住宿</span>
                    <span className="text-sm font-medium text-text-primary">¥3,800</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">交通</span>
                    <span className="text-sm font-medium text-text-primary">¥1,200</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">门票</span>
                    <span className="text-sm font-medium text-text-primary">¥300</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 每日行程区 */}
        <section className="px-6 pb-6">
          <div className="bg-white rounded-xl shadow-card p-6">
            <h2 className="text-xl font-semibold text-text-primary mb-6">详细行程</h2>
            
            {/* 第1天 */}
            <div className="mb-8">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center mr-3">
                  <span className="text-white font-bold">1</span>
                </div>
                <div>
                  <h3 className={`text-lg font-semibold text-text-primary ${styles.editable}`}>第1天 - 3月15日 (周五)</h3>
                  <p className={`text-sm text-text-secondary ${styles.editable}`}>抵达东京，浅草寺观光</p>
                </div>
              </div>
              
              <div className="ml-13 space-y-4">
                {/* 活动1 */}
                <div 
                  className={`${styles.activityItem} ${styles.timelineItem} ${styles.timelineLine} flex items-start space-x-4 p-4 rounded-lg cursor-pointer`}
                  onClick={() => handleActivityClick('activity-1')}
                >
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="fas fa-plane text-white text-sm"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className={`font-medium text-text-primary ${styles.editable}`}>抵达东京成田机场</h4>
                      <span className="text-sm text-text-secondary">09:00</span>
                    </div>
                    <p className={`text-sm text-text-secondary mb-2 ${styles.editable}`}>乘坐CA157航班抵达东京成田机场</p>
                    <div className="flex items-center space-x-4 text-xs text-text-secondary">
                      <span><i className="fas fa-map-marker-alt mr-1"></i>成田国际机场</span>
                      <span><i className="fas fa-yen-sign mr-1"></i>¥0</span>
                    </div>
                  </div>
                </div>
                
                {/* 活动2 */}
                <div 
                  className={`${styles.activityItem} ${styles.timelineItem} ${styles.timelineLine} flex items-start space-x-4 p-4 rounded-lg cursor-pointer`}
                  onClick={() => handleActivityClick('activity-2')}
                >
                  <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="fas fa-subway text-white text-sm"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className={`font-medium text-text-primary ${styles.editable}`}>前往酒店</h4>
                      <span className="text-sm text-text-secondary">10:30</span>
                    </div>
                    <p className={`text-sm text-text-secondary mb-2 ${styles.editable}`}>乘坐成田特快前往市区，入住酒店</p>
                    <div className="flex items-center space-x-4 text-xs text-text-secondary">
                      <span><i className="fas fa-map-marker-alt mr-1"></i>成田机场 → 新宿</span>
                      <span><i className="fas fa-yen-sign mr-1"></i>¥3,000</span>
                    </div>
                  </div>
                </div>
                
                {/* 活动3 */}
                <div 
                  className={`${styles.activityItem} ${styles.timelineItem} ${styles.timelineLine} flex items-start space-x-4 p-4 rounded-lg cursor-pointer`}
                  onClick={() => handleActivityClick('activity-3')}
                >
                  <div className="w-8 h-8 bg-tertiary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="fas fa-torii-gate text-white text-sm"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className={`font-medium text-text-primary ${styles.editable}`}>浅草寺观光</h4>
                      <span className="text-sm text-text-secondary">14:00</span>
                    </div>
                    <p className={`text-sm text-text-secondary mb-2 ${styles.editable}`}>参观东京最古老的寺庙，体验传统文化</p>
                    <div className="flex items-center space-x-4 text-xs text-text-secondary">
                      <span><i className="fas fa-map-marker-alt mr-1"></i>浅草寺</span>
                      <span><i className="fas fa-yen-sign mr-1"></i>免费</span>
                    </div>
                  </div>
                </div>
                
                {/* 活动4 */}
                <div 
                  className={`${styles.activityItem} ${styles.timelineItem} flex items-start space-x-4 p-4 rounded-lg cursor-pointer`}
                  onClick={() => handleActivityClick('activity-4')}
                >
                  <div className="w-8 h-8 bg-warning rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="fas fa-utensils text-white text-sm"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className={`font-medium text-text-primary ${styles.editable}`}>一兰拉面晚餐</h4>
                      <span className="text-sm text-text-secondary">19:00</span>
                    </div>
                    <p className={`text-sm text-text-secondary mb-2 ${styles.editable}`}>品尝正宗的豚骨拉面，体验日本拉面文化</p>
                    <div className="flex items-center space-x-4 text-xs text-text-secondary">
                      <span><i className="fas fa-map-marker-alt mr-1"></i>一兰拉面 浅草店</span>
                      <span><i className="fas fa-yen-sign mr-1"></i>¥1,200</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 第2天 */}
            <div className="mb-8">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-secondary to-tertiary rounded-lg flex items-center justify-center mr-3">
                  <span className="text-white font-bold">2</span>
                </div>
                <div>
                  <h3 className={`text-lg font-semibold text-text-primary ${styles.editable}`}>第2天 - 3月16日 (周六)</h3>
                  <p className={`text-sm text-text-secondary ${styles.editable}`}>明治神宫，涩谷购物</p>
                </div>
              </div>
              
              <div className="ml-13 space-y-4">
                {/* 活动5 */}
                <div 
                  className={`${styles.activityItem} ${styles.timelineItem} ${styles.timelineLine} flex items-start space-x-4 p-4 rounded-lg cursor-pointer`}
                  onClick={() => handleActivityClick('activity-5')}
                >
                  <div className="w-8 h-8 bg-success rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="fas fa-tree text-white text-sm"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className={`font-medium text-text-primary ${styles.editable}`}>明治神宫参拜</h4>
                      <span className="text-sm text-text-secondary">10:00</span>
                    </div>
                    <p className={`text-sm text-text-secondary mb-2 ${styles.editable}`}>在东京市中心的绿洲中感受宁静与神圣</p>
                    <div className="flex items-center space-x-4 text-xs text-text-secondary">
                      <span><i className="fas fa-map-marker-alt mr-1"></i>明治神宫</span>
                      <span><i className="fas fa-yen-sign mr-1"></i>免费</span>
                    </div>
                  </div>
                </div>
                
                {/* 活动6 */}
                <div 
                  className={`${styles.activityItem} ${styles.timelineItem} flex items-start space-x-4 p-4 rounded-lg cursor-pointer`}
                  onClick={() => handleActivityClick('activity-6')}
                >
                  <div className="w-8 h-8 bg-danger rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="fas fa-shopping-bag text-white text-sm"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className={`font-medium text-text-primary ${styles.editable}`}>涩谷购物</h4>
                      <span className="text-sm text-text-secondary">14:00</span>
                    </div>
                    <p className={`text-sm text-text-secondary mb-2 ${styles.editable}`}>在东京最繁华的商业区尽情购物</p>
                    <div className="flex items-center space-x-4 text-xs text-text-secondary">
                      <span><i className="fas fa-map-marker-alt mr-1"></i>涩谷区</span>
                      <span><i className="fas fa-yen-sign mr-1"></i>¥2,000</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* 活动详情抽屉 */}
      <div className={`fixed inset-y-0 right-0 w-96 bg-white shadow-2xl z-50 transform transition-transform duration-300 ${showActivityDrawer ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-border-light">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-text-primary">活动详情</h3>
              <button 
                onClick={handleCloseDrawer}
                className="p-2 text-text-secondary hover:text-text-primary"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4">
            {selectedActivity && (
              <div className="space-y-4">
                <img 
                  src={selectedActivity.image} 
                  alt={selectedActivity.title} 
                  className="w-full h-48 object-cover rounded-lg"
                />
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-text-secondary">
                    <i className="fas fa-clock mr-2"></i>
                    <span>{selectedActivity.time}</span>
                  </div>
                  <div className="flex items-center text-sm text-text-secondary">
                    <i className="fas fa-map-marker-alt mr-2"></i>
                    <span>{selectedActivity.location}</span>
                  </div>
                  <div className="flex items-center text-sm text-text-secondary">
                    <i className="fas fa-tag mr-2"></i>
                    <span>{selectedActivity.category}</span>
                  </div>
                  <div className="flex items-center text-sm text-text-secondary">
                    <i className="fas fa-yen-sign mr-2"></i>
                    <span>{selectedActivity.cost}</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-text-primary mb-2">详细描述</h4>
                  <p className="text-sm text-text-secondary leading-relaxed">{selectedActivity.description}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 抽屉遮罩 */}
      <div 
        className={`fixed inset-0 bg-black bg-opacity-50 z-40 ${showActivityDrawer ? '' : 'hidden'} ${styles.drawerOverlay}`}
        onClick={() => handleCloseDrawer()}
      ></div>

      {/* 记录开销弹窗 */}
      <div 
        className={`fixed inset-0 bg-black bg-opacity-50 z-50 ${showExpenseModal ? '' : 'hidden'} ${styles.modalOverlay}`}
        onClick={(e) => handleModalOverlayClick(e, setShowExpenseModal)}
      >
        <div className="flex items-center justify-center min-h-screen p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-text-primary">记录开销</h3>
                <button 
                  onClick={() => handleCloseModal(setShowExpenseModal)}
                  className="p-2 text-text-secondary hover:text-text-primary"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>
              <form onSubmit={handleExpenseSubmit} className="space-y-4">
                <div>
                  <label htmlFor="expense-amount" className="block text-sm font-medium text-text-primary mb-2">金额</label>
                  <input 
                    type="number" 
                    id="expense-amount" 
                    name="amount" 
                    value={expenseFormData.amount}
                    onChange={handleExpenseInputChange}
                    className="w-full px-3 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                    placeholder="请输入金额" 
                    required 
                  />
                </div>
                <div>
                  <label htmlFor="expense-category" className="block text-sm font-medium text-text-primary mb-2">类别</label>
                  <select 
                    id="expense-category" 
                    name="category" 
                    value={expenseFormData.category}
                    onChange={handleExpenseInputChange}
                    className="w-full px-3 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                    required
                  >
                    <option value="">请选择类别</option>
                    <option value="餐饮">餐饮</option>
                    <option value="住宿">住宿</option>
                    <option value="交通">交通</option>
                    <option value="购物">购物</option>
                    <option value="门票">门票</option>
                    <option value="其他">其他</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="expense-date" className="block text-sm font-medium text-text-primary mb-2">日期</label>
                  <input 
                    type="date" 
                    id="expense-date" 
                    name="date" 
                    value={expenseFormData.date}
                    onChange={handleExpenseInputChange}
                    className="w-full px-3 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                    required 
                  />
                </div>
                <div>
                  <label htmlFor="expense-description" className="block text-sm font-medium text-text-primary mb-2">备注</label>
                  <textarea 
                    id="expense-description" 
                    name="description" 
                    rows={3}
                    value={expenseFormData.description}
                    onChange={handleExpenseInputChange}
                    className="w-full px-3 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                    placeholder="请输入备注信息"
                  ></textarea>
                </div>
                <div className="flex space-x-3 pt-4">
                  <button 
                    type="button" 
                    onClick={() => handleCloseModal(setShowExpenseModal)}
                    className="flex-1 px-4 py-2 text-text-secondary border border-border-light rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    type="submit" 
                    className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    保存
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* 分享弹窗 */}
      <div 
        className={`fixed inset-0 bg-black bg-opacity-50 z-50 ${showShareModal ? '' : 'hidden'} ${styles.modalOverlay}`}
        onClick={(e) => handleModalOverlayClick(e, setShowShareModal)}
      >
        <div className="flex items-center justify-center min-h-screen p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-text-primary">分享行程</h3>
                <button 
                  onClick={() => handleCloseModal(setShowShareModal)}
                  className="p-2 text-text-secondary hover:text-text-primary"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">分享链接</label>
                  <div className="flex">
                    <input 
                      type="text" 
                      value="https://tuzhixing.com/share/trip/abc123" 
                      readOnly 
                      className="flex-1 px-3 py-2 border border-border-light rounded-l-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-gray-50"
                    />
                    <button 
                      onClick={handleCopyLink}
                      className="px-4 py-2 bg-primary text-white rounded-r-lg hover:bg-blue-600 transition-colors"
                    >
                      <i className="fas fa-copy"></i>
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 pt-4">
                  <button 
                    onClick={() => handleSocialShare('微信')}
                    className="flex flex-col items-center p-4 border border-border-light rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <i className="fab fa-weixin text-2xl text-success mb-2"></i>
                    <span className="text-sm text-text-primary">微信</span>
                  </button>
                  <button 
                    onClick={() => handleSocialShare('QQ')}
                    className="flex flex-col items-center p-4 border border-border-light rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <i className="fab fa-qq text-2xl text-info mb-2"></i>
                    <span className="text-sm text-text-primary">QQ</span>
                  </button>
                  <button 
                    onClick={() => handleSocialShare('微博')}
                    className="flex flex-col items-center p-4 border border-border-light rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <i className="fab fa-weibo text-2xl text-danger mb-2"></i>
                    <span className="text-sm text-text-primary">微博</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 删除确认弹窗 */}
      <div 
        className={`fixed inset-0 bg-black bg-opacity-50 z-50 ${showDeleteModal ? '' : 'hidden'} ${styles.modalOverlay}`}
        onClick={(e) => handleModalOverlayClick(e, setShowDeleteModal)}
      >
        <div className="flex items-center justify-center min-h-screen p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md">
            <div className="p-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-exclamation-triangle text-danger text-2xl"></i>
                </div>
                <h3 className="text-lg font-semibold text-text-primary mb-2">确认删除</h3>
                <p className="text-text-secondary mb-6">删除后将无法恢复，确定要删除这个行程吗？</p>
                <div className="flex space-x-3">
                  <button 
                    onClick={() => handleCloseModal(setShowDeleteModal)}
                    className="flex-1 px-4 py-2 text-text-secondary border border-border-light rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    onClick={handleConfirmDelete}
                    className="flex-1 px-4 py-2 bg-danger text-white rounded-lg hover:bg-red-600 transition-colors"
                  >
                    删除
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlanDetailPage;

