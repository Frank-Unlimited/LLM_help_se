

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface Expense {
  id: number;
  date: string;
  category: string;
  amount: number;
  description: string;
}

interface TripData {
  name: string;
  totalBudget: number;
  spent: number;
}

const BudgetManagePage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // 状态管理
  const [expenses, setExpenses] = useState<Expense[]>([
    { id: 1, date: '2024-03-15', category: '餐饮', amount: 280, description: '午餐 - 寿司店' },
    { id: 2, date: '2024-03-15', category: '交通', amount: 120, description: '地铁卡充值' },
    { id: 3, date: '2024-03-15', category: '景点', amount: 450, description: '浅草寺门票' },
    { id: 4, date: '2024-03-16', category: '餐饮', amount: 350, description: '早餐 - 酒店' },
    { id: 5, date: '2024-03-16', category: '交通', amount: 80, description: '出租车' },
    { id: 6, date: '2024-03-16', category: '购物', amount: 200, description: '纪念品' },
    { id: 7, date: '2024-03-17', category: '餐饮', amount: 420, description: '晚餐 - 拉面店' },
    { id: 8, date: '2024-03-17', category: '交通', amount: 60, description: '巴士' },
    { id: 9, date: '2024-03-17', category: '景点', amount: 300, description: '上野公园' },
    { id: 10, date: '2024-03-18', category: '餐饮', amount: 220, description: '午餐 - 便当' },
    { id: 11, date: '2024-03-18', category: '交通', amount: 150, description: '新干线' },
    { id: 12, date: '2024-03-18', category: '购物', amount: 300, description: '化妆品' }
  ]);
  
  const [currentFilter, setCurrentFilter] = useState<string>('all');
  const [currentSort, setCurrentSort] = useState<string>('date-desc');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isModalActive, setIsModalActive] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editingExpenseId, setEditingExpenseId] = useState<number | null>(null);
  const [isSidebarVisible, setIsSidebarVisible] = useState<boolean>(false);
  
  // 表单状态
  const [formData, setFormData] = useState({
    date: '',
    category: '',
    amount: '',
    description: ''
  });

  const pageSize = 10;

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '预算管理 - 途智行';
    return () => { document.title = originalTitle; };
  }, []);

  // 响应式处理
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsSidebarVisible(false);
      }
    };
    
    window.addEventListener('resize', handleResize);
    handleResize();
    
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // 加载行程数据
  const loadTripBudget = (tripId: string): TripData => {
    const mockTripData: Record<string, TripData> = {
      'trip1': { name: '日本东京 · 5天4夜', totalBudget: 10000, spent: 6850 },
      'trip2': { name: '欧洲三国 · 10天9夜', totalBudget: 25000, spent: 18000 },
      'trip3': { name: '云南大理 · 7天6夜', totalBudget: 8000, spent: 5200 }
    };
    return mockTripData[tripId] || mockTripData['trip1'];
  };

  const tripData = loadTripBudget(searchParams.get('tripId') || 'trip1');

  // 筛选开销数据
  const getFilteredExpenses = (): Expense[] => {
    return expenses.filter(expense => {
      if (currentFilter === 'all') return true;
      
      const categoryMap: Record<string, string> = {
        'food': '餐饮',
        'transport': '交通', 
        'attraction': '景点',
        'shopping': '购物'
      };
      
      return expense.category === categoryMap[currentFilter];
    });
  };

  // 排序开销数据
  const sortExpenses = (expensesToSort: Expense[]): Expense[] => {
    return [...expensesToSort].sort((a, b) => {
      switch (currentSort) {
        case 'date-desc':
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        case 'date-asc':
          return new Date(a.date).getTime() - new Date(b.date).getTime();
        case 'amount-desc':
          return b.amount - a.amount;
        case 'amount-asc':
          return a.amount - b.amount;
        case 'category':
          return a.category.localeCompare(b.category);
        default:
          return new Date(b.date).getTime() - new Date(a.date).getTime();
      }
    });
  };

  // 获取分页数据
  const getPagedExpenses = (): Expense[] => {
    const filteredExpenses = getFilteredExpenses();
    const sortedExpenses = sortExpenses(filteredExpenses);
    
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    return sortedExpenses.slice(startIndex, endIndex);
  };

  // 计算总花费
  const getTotalSpent = (): number => {
    return expenses.reduce((sum, expense) => sum + expense.amount, 0);
  };

  // 格式化日期
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', { 
      year: 'numeric', 
      month: '2-digit', 
      day: '2-digit' 
    });
  };

  // 获取类别颜色
  const getCategoryColor = (category: string): string => {
    const colorMap: Record<string, string> = {
      '餐饮': 'bg-blue-100 text-blue-800',
      '交通': 'bg-yellow-100 text-yellow-800',
      '景点': 'bg-green-100 text-green-800',
      '购物': 'bg-purple-100 text-purple-800',
      '住宿': 'bg-red-100 text-red-800',
      '其他': 'bg-gray-100 text-gray-800'
    };
    return colorMap[category] || 'bg-gray-100 text-gray-800';
  };

  // 处理表单输入
  const handleFormInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // 打开记录开销弹窗
  const handleRecordExpenseClick = () => {
    const today = new Date().toISOString().split('T')[0];
    setFormData({
      date: today,
      category: '',
      amount: '',
      description: ''
    });
    setIsEditing(false);
    setEditingExpenseId(null);
    setIsModalActive(true);
  };

  // 编辑开销记录
  const handleEditExpense = (id: number) => {
    const expense = expenses.find(e => e.id === id);
    if (!expense) return;
    
    setFormData({
      date: expense.date,
      category: expense.category,
      amount: expense.amount.toString(),
      description: expense.description
    });
    setIsEditing(true);
    setEditingExpenseId(id);
    setIsModalActive(true);
  };

  // 删除开销记录
  const handleDeleteExpense = (id: number) => {
    if (confirm('确定要删除这条开销记录吗？')) {
      setExpenses(prev => prev.filter(e => e.id !== id));
    }
  };

  // 提交表单
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isEditing && editingExpenseId) {
      // 编辑模式
      setExpenses(prev => prev.map(expense => 
        expense.id === editingExpenseId 
          ? {
              ...expense,
              date: formData.date,
              category: formData.category,
              amount: parseFloat(formData.amount),
              description: formData.description
            }
          : expense
      ));
    } else {
      // 添加模式
      const newExpense: Expense = {
        id: Math.max(...expenses.map(e => e.id)) + 1,
        date: formData.date,
        category: formData.category,
        amount: parseFloat(formData.amount),
        description: formData.description
      };
      
      setExpenses(prev => [...prev, newExpense]);
    }
    
    setIsModalActive(false);
    setFormData({
      date: '',
      category: '',
      amount: '',
      description: ''
    });
  };

  // 关闭弹窗
  const handleCloseModal = () => {
    setIsModalActive(false);
    setFormData({
      date: '',
      category: '',
      amount: '',
      description: ''
    });
    setIsEditing(false);
    setEditingExpenseId(null);
  };

  // 处理筛选
  const handleFilterChange = (filter: string) => {
    setCurrentFilter(filter);
    setCurrentPage(1);
  };

  // 处理排序
  const handleSortChange = (sort: string) => {
    setCurrentSort(sort);
  };

  // 处理分页
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // 处理导出
  const handleExport = () => {
    console.log('导出开销记录');
  };

  // 侧边栏切换
  const handleSidebarToggle = () => {
    setIsSidebarVisible(!isSidebarVisible);
  };

  const filteredExpenses = getFilteredExpenses();
  const pagedExpenses = getPagedExpenses();
  const totalSpent = getTotalSpent();
  const remaining = tripData.totalBudget - totalSpent;
  const totalPages = Math.ceil(filteredExpenses.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize + 1;
  const endIndex = Math.min(currentPage * pageSize, filteredExpenses.length);

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
              <i className="fas fa-route text-white text-lg"></i>
            </div>
            <h1 className="text-xl font-bold text-text-primary">途智行</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/my-trips" className="text-text-primary font-medium border-b-2 border-primary py-1">我的行程</Link>
            <Link to="/user-profile" className="text-text-secondary hover:text-primary py-1 transition-colors">个人中心</Link>
          </nav>
          
          {/* 搜索框和用户操作区 */}
          <div className="flex items-center space-x-4">
            <div className="hidden lg:block">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="搜索目的地..." 
                  className="w-64 pl-10 pr-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <img 
                src="https://s.coze.cn/image/SxIXNR2TFDI/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full"
              />
              <span className="text-text-primary font-medium">小雨</span>
            </div>
            <button 
              onClick={handleSidebarToggle}
              className="md:hidden p-2 text-text-secondary hover:text-primary"
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>
        </div>
      </header>

      {/* 左侧菜单 */}
      <aside className={`fixed left-0 top-16 bottom-0 w-60 bg-white shadow-sm z-40 ${styles.sidebarTransition} ${isSidebarVisible ? '' : '-translate-x-full md:translate-x-0'}`}>
        <div className="p-4">
          <nav className="space-y-2">
            <Link to="/home" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-home text-lg"></i>
              <span>首页</span>
            </Link>
            <Link to="/plan-input" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-route text-lg"></i>
              <span>行程规划</span>
            </Link>
            <Link to="/my-trips" className="flex items-center space-x-3 px-4 py-3 text-primary bg-blue-50 rounded-lg">
              <i className="fas fa-list text-lg"></i>
              <span className="font-medium">我的行程</span>
            </Link>
            <Link to="/budget-manage" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-wallet text-lg"></i>
              <span>预算管理</span>
            </Link>
            <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 text-text-secondary hover:text-primary hover:bg-gray-50 rounded-lg transition-colors">
              <i className="fas fa-user text-lg"></i>
              <span>个人中心</span>
            </Link>
          </nav>
        </div>
      </aside>

      {/* 主内容区 */}
      <main className="ml-60 mt-16 min-h-screen transition-all duration-300 md:ml-60">
        {/* 页面头部 */}
        <div className="bg-white border-b border-border-light px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <nav className="text-sm text-text-secondary mb-2">
                <Link to="/my-trips" className="hover:text-primary">我的行程</Link>
                <span className="mx-2">/</span>
                <span className="text-text-primary">预算管理</span>
              </nav>
              <h1 className="text-2xl font-bold text-text-primary">预算管理</h1>
              <p className="text-text-secondary mt-1">{tripData.name}</p>
            </div>
            <button 
              onClick={handleRecordExpenseClick}
              className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center space-x-2"
            >
              <i className="fas fa-plus"></i>
              <span>记录开销</span>
            </button>
          </div>
        </div>

        {/* 预算概览区 */}
        <section className="p-6">
          <div className="bg-white rounded-xl shadow-card p-6">
            <h2 className="text-xl font-semibold text-text-primary mb-6">预算概览</h2>
            
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {/* 总预算 */}
              <div className="text-center p-4 bg-gradient-to-br from-primary to-secondary rounded-lg text-white">
                <div className="text-3xl font-bold mb-1">¥{tripData.totalBudget.toLocaleString()}</div>
                <div className="text-sm opacity-90">总预算</div>
              </div>
              
              {/* 已花费 */}
              <div className="text-center p-4 bg-gradient-to-br from-warning to-danger rounded-lg text-white">
                <div className="text-3xl font-bold mb-1">¥{totalSpent.toLocaleString()}</div>
                <div className="text-sm opacity-90">已花费</div>
              </div>
              
              {/* 剩余预算 */}
              <div className="text-center p-4 bg-gradient-to-br from-success to-tertiary rounded-lg text-white">
                <div className="text-3xl font-bold mb-1">¥{remaining.toLocaleString()}</div>
                <div className="text-sm opacity-90">剩余预算</div>
              </div>
            </div>
            
            {/* 预算对比图表 */}
            <div className="grid md:grid-cols-2 gap-8">
              {/* 饼图 */}
              <div className={styles.chartContainer}>
                <h3 className="text-lg font-medium text-text-primary mb-4">预算分配</h3>
                <div className="relative h-full flex items-center justify-center">
                  <div className="relative w-48 h-48">
                    {/* 模拟饼图 */}
                    <svg className="w-48 h-48 transform -rotate-90" viewBox="0 0 42 42">
                      <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="#E5E7EB" strokeWidth="3"></circle>
                      <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="#3B82F6" strokeWidth="3" 
                              strokeDasharray="45 55" strokeDashoffset="0"></circle>
                      <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="#F59E0B" strokeWidth="3" 
                              strokeDasharray="25 75" strokeDashoffset="-45"></circle>
                      <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="#10B981" strokeWidth="3" 
                              strokeDasharray="20 80" strokeDashoffset="-70"></circle>
                      <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="#8B5CF6" strokeWidth="3" 
                              strokeDasharray="10 90" strokeDashoffset="-90"></circle>
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-text-primary">¥{totalSpent.toLocaleString()}</div>
                        <div className="text-sm text-text-secondary">已花费</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-primary rounded-full"></div>
                      <span className="text-sm text-text-secondary">餐饮</span>
                    </div>
                    <span className="text-sm font-medium text-text-primary">¥2,200 (45%)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-warning rounded-full"></div>
                      <span className="text-sm text-text-secondary">交通</span>
                    </div>
                    <span className="text-sm font-medium text-text-primary">¥1,250 (25%)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-success rounded-full"></div>
                      <span className="text-sm text-text-secondary">景点</span>
                    </div>
                    <span className="text-sm font-medium text-text-primary">¥1,000 (20%)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-secondary rounded-full"></div>
                      <span className="text-sm text-text-secondary">购物</span>
                    </div>
                    <span className="text-sm font-medium text-text-primary">¥500 (10%)</span>
                  </div>
                </div>
              </div>
              
              {/* 每日开销 */}
              <div className={styles.chartContainer}>
                <h3 className="text-lg font-medium text-text-primary mb-4">每日开销</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">第1天</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{width: '80%'}}></div>
                      </div>
                      <span className="text-sm font-medium text-text-primary">¥1,450</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">第2天</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{width: '95%'}}></div>
                      </div>
                      <span className="text-sm font-medium text-text-primary">¥1,650</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">第3天</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{width: '70%'}}></div>
                      </div>
                      <span className="text-sm font-medium text-text-primary">¥1,200</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">第4天</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{width: '85%'}}></div>
                      </div>
                      <span className="text-sm font-medium text-text-primary">¥1,500</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">第5天</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-gray-300 h-2 rounded-full" style={{width: '0%'}}></div>
                      </div>
                      <span className="text-sm font-medium text-text-secondary">待开始</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 开销记录区 */}
        <section className="px-6 pb-6">
          <div className="bg-white rounded-xl shadow-card">
            {/* 筛选和排序 */}
            <div className="p-6 border-b border-border-light">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                <div className="flex items-center space-x-4">
                  <h2 className="text-xl font-semibold text-text-primary">开销明细</h2>
                  <div className="flex items-center space-x-2">
                    <button 
                      onClick={() => handleFilterChange('all')}
                      className={`px-3 py-1 text-sm rounded-full transition-colors ${
                        currentFilter === 'all' ? styles.filterActive : styles.filterInactive
                      }`}
                    >
                      全部
                    </button>
                    <button 
                      onClick={() => handleFilterChange('food')}
                      className={`px-3 py-1 text-sm rounded-full transition-colors ${
                        currentFilter === 'food' ? styles.filterActive : styles.filterInactive
                      }`}
                    >
                      餐饮
                    </button>
                    <button 
                      onClick={() => handleFilterChange('transport')}
                      className={`px-3 py-1 text-sm rounded-full transition-colors ${
                        currentFilter === 'transport' ? styles.filterActive : styles.filterInactive
                      }`}
                    >
                      交通
                    </button>
                    <button 
                      onClick={() => handleFilterChange('attraction')}
                      className={`px-3 py-1 text-sm rounded-full transition-colors ${
                        currentFilter === 'attraction' ? styles.filterActive : styles.filterInactive
                      }`}
                    >
                      景点
                    </button>
                    <button 
                      onClick={() => handleFilterChange('shopping')}
                      className={`px-3 py-1 text-sm rounded-full transition-colors ${
                        currentFilter === 'shopping' ? styles.filterActive : styles.filterInactive
                      }`}
                    >
                      购物
                    </button>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <select 
                    value={currentSort}
                    onChange={(e) => handleSortChange(e.target.value)}
                    className="px-3 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="date-desc">按日期倒序</option>
                    <option value="date-asc">按日期正序</option>
                    <option value="amount-desc">按金额倒序</option>
                    <option value="amount-asc">按金额正序</option>
                    <option value="category">按类别</option>
                  </select>
                  <button 
                    onClick={handleExport}
                    className="px-4 py-2 border border-border-light rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2"
                  >
                    <i className="fas fa-download"></i>
                    <span>导出</span>
                  </button>
                </div>
              </div>
            </div>
            
            {/* 开销明细表格 */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">日期</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">类别</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">金额</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">描述</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">操作</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {pagedExpenses.map(expense => (
                    <tr key={expense.id} className={styles.tableRow}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">
                        {formatDate(expense.date)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-3 py-1 text-sm font-medium rounded-full ${getCategoryColor(expense.category)}`}>
                          {expense.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-text-primary">
                        ¥{expense.amount.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-sm text-text-secondary">
                        {expense.description || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <button 
                          onClick={() => handleEditExpense(expense.id)}
                          className="text-primary hover:text-blue-600 transition-colors"
                        >
                          <i className="fas fa-edit"></i>
                        </button>
                        <button 
                          onClick={() => handleDeleteExpense(expense.id)}
                          className="text-danger hover:text-red-600 transition-colors"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {/* 分页 */}
            <div className="px-6 py-4 border-t border-border-light">
              <div className="flex items-center justify-between">
                <div className="text-sm text-text-secondary">
                  显示第 <span>{startIndex}</span> - <span>{endIndex}</span> 条，共 <span>{filteredExpenses.length}</span> 条记录
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="px-3 py-1 border border-border-light rounded hover:bg-gray-50 transition-colors disabled:opacity-50"
                  >
                    <i className="fas fa-chevron-left"></i>
                  </button>
                  {[1, 2, 3].map(page => (
                    <button 
                      key={page}
                      onClick={() => handlePageChange(page)}
                      className={`px-3 py-1 rounded transition-colors ${
                        currentPage === page 
                          ? 'bg-primary text-white' 
                          : 'border border-border-light hover:bg-gray-50'
                      }`}
                    >
                      {page}
                    </button>
                  ))}
                  <button 
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className="px-3 py-1 border border-border-light rounded hover:bg-gray-50 transition-colors disabled:opacity-50"
                  >
                    <i className="fas fa-chevron-right"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* 开销记录弹窗 */}
      {isModalActive && (
        <div className={styles.expenseModal} onClick={handleCloseModal}>
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b border-border-light relative">
              <h3 className="text-xl font-semibold text-text-primary">
                {isEditing ? '编辑开销' : '记录开销'}
              </h3>
              <button 
                onClick={handleCloseModal}
                className="absolute top-4 right-4 text-text-secondary hover:text-text-primary"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <form onSubmit={handleFormSubmit} className="p-6 space-y-4">
              <div>
                <label htmlFor="expense-date" className="block text-sm font-medium text-text-primary mb-2">日期</label>
                <input 
                  type="date" 
                  id="expense-date" 
                  value={formData.date}
                  onChange={(e) => handleFormInputChange('date', e.target.value)}
                  className="w-full px-3 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary" 
                  required 
                />
              </div>
              <div>
                <label htmlFor="expense-category" className="block text-sm font-medium text-text-primary mb-2">类别</label>
                <select 
                  id="expense-category" 
                  value={formData.category}
                  onChange={(e) => handleFormInputChange('category', e.target.value)}
                  className="w-full px-3 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary" 
                  required
                >
                  <option value="">请选择类别</option>
                  <option value="餐饮">餐饮</option>
                  <option value="交通">交通</option>
                  <option value="景点">景点</option>
                  <option value="购物">购物</option>
                  <option value="住宿">住宿</option>
                  <option value="其他">其他</option>
                </select>
              </div>
              <div>
                <label htmlFor="expense-amount" className="block text-sm font-medium text-text-primary mb-2">金额</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary">¥</span>
                  <input 
                    type="number" 
                    id="expense-amount" 
                    min="0" 
                    step="0.01"
                    value={formData.amount}
                    onChange={(e) => handleFormInputChange('amount', e.target.value)}
                    className="w-full pl-8 pr-3 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary" 
                    placeholder="0.00" 
                    required 
                  />
                </div>
              </div>
              <div>
                <label htmlFor="expense-description" className="block text-sm font-medium text-text-primary mb-2">描述</label>
                <textarea 
                  id="expense-description" 
                  rows={3}
                  value={formData.description}
                  onChange={(e) => handleFormInputChange('description', e.target.value)}
                  className="w-full px-3 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary" 
                  placeholder="请输入开销描述..."
                ></textarea>
              </div>
              <div className="flex space-x-3 pt-4">
                <button 
                  type="button" 
                  onClick={handleCloseModal}
                  className="flex-1 px-4 py-2 border border-border-light rounded-lg hover:bg-gray-50 transition-colors"
                >
                  取消
                </button>
                <button 
                  type="submit" 
                  className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors"
                >
                  保存
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BudgetManagePage;

